#include <bits/stdc++.h>
using namespace std;
char cp_ver[] = "0.0.1 for Linux";
void help() {
	printf("\n------------------------\nConsolePauser version %s by Allenyou\n\nUseage:\n\nConsolePauser [-h] <Program name> <arg1> <arg2> ...\n\n[-h] Show this Help.\n<Program name> Your Program name.\n", cp_ver);
}
string toString(const char *str) {
	string tmp_str = "";
	int len = strlen(str);
	for (register int i = 0; i < len; ++i) {
		tmp_str += str[i];
	}
	return tmp_str;
}
int main(int argc, char const *argv[]) {
	if (argc < 2) {
		help();
		return 0;
	}
	if (toString(argv[1]) == "-h") {
		help();
		return 0;
	}
	string cmd_str = toString(argv[1]);
	for (register int i = 2; i < argc; ++i) {
		cmd_str += " ";
		cmd_str += toString(argv[i]);
	}
	int ts = clock();
	int ret_val = system(cmd_str.c_str());
	int tt = clock();
	double run_t = (tt - ts) * 0.001;
	printf("\n------------------------\nProcessed exited in %.3lf seconds with return value %d\n", run_t, ret_val);
	system("pause");
	return ret_val;
}